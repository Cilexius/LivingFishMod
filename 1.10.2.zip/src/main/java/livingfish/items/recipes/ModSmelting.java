package livingfish.items.recipes;

public class ModSmelting {
	
	public void register() {

	}
	
}
