package livingfish.proxys;

import livingfish.init.ModBlocks;
import livingfish.init.ModEntities;
import livingfish.init.ModItems;

public class ClientProxy extends CommonProxy {
	
	public void register() {
		ModItems.registerModel();
		ModBlocks.registerModel();
		ModEntities.registerRender();
	}
	
}
