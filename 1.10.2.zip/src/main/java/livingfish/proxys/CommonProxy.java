package livingfish.proxys;

public class CommonProxy {
	
	public void register() {
	}
	
}
