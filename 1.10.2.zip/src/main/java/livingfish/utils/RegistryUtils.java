package livingfish.utils;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;

public class RegistryUtils {
	
	public static void registerModel(Object obj, int meta, ModelResourceLocation loc) {
		Item item = null;
		if (obj instanceof Item) {
			item = (Item) obj;
		} else if (obj instanceof Block) {
			item = Item.getItemFromBlock((Block)obj); 
		} else {
			throw new IllegalArgumentException();
		}
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, meta, loc);			
	}
	
	public static void setNames(Object obj, String name) {
		if (obj instanceof Item) {
			((Item) obj).setRegistryName(name).setUnlocalizedName(name);
		} else if (obj instanceof Block) {
			((Block) obj).setRegistryName(name).setUnlocalizedName(name);
		} else {
			throw new IllegalArgumentException();
		}
	}
}
