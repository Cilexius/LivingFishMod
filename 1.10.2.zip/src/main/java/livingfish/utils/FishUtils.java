package livingfish.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import livingfish.entities.EntityClownFish;
import livingfish.entities.EntityCod;
import livingfish.entities.EntityFish;
import livingfish.entities.EntityPufferFish;
import livingfish.entities.EntitySalmon;
import livingfish.init.ModItems;
import livingfish.items.ItemFishBucket;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class FishUtils {
	
	List <String> spawnList = new ArrayList<String>();
	
	public static ItemFishBucket getFishBucketByFish(EntityFish fish) {
		if (fish instanceof EntitySalmon) {
			return (ItemFishBucket) ModItems.fish_bucket_salmon;
		} else if (fish instanceof EntityClownFish) {
			return (ItemFishBucket) ModItems.fish_bucket_clownfish;
		} else if (fish instanceof EntityPufferFish) {
			return (ItemFishBucket) ModItems.fish_bucket_pufferfish;
		} else {
			return (ItemFishBucket) ModItems.fish_bucket_cod;
		}
	}
	
	public static EntityFish getFishByName(String fishName, World world) {
		if (fishName == "salmon") {
			return new EntitySalmon(world);
		} else if (fishName == "clownfish") {
			return new EntityClownFish(world);
		} else if (fishName == "pufferfish") {
			return new EntityPufferFish(world);
		} else {
			return new EntityCod(world);
		}
	}
	
	public static void spawnFishByName(String fishName, boolean isChild, World world, BlockPos pos) {
		if (pos != null) {
			EntityFish fish;
			if (fishName == "salmon") {
				fish = new EntitySalmon(world);
			} else if (fishName == "clownfish") {
				fish = new EntityClownFish(world);
			} else if (fishName == "pufferfish") {
				fish = new EntityPufferFish(world);
			} else {
				fish = new EntityCod(world);
			}
			if (isChild) {
				fish.setGrowingAge(-24000);
			}
	        fish.setLocationAndAngles(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5F, 0.0F, 0.0F);
	        world.spawnEntityInWorld(fish);
		}
	}
	
	public static void trySpawn(World world) {
		
		for (EntityPlayer player : world.playerEntities) {

			BlockPos pos = player.getPosition();
			IBlockState blockState = world.getBlockState(pos);
			Material material = blockState.getMaterial();
			int spawnRange = 32;
			int maxProPlayer = 60;
			
			List<EntityFish> fishList = new ArrayList<EntityFish>();
			List<EntityFish> list = player.worldObj.getEntitiesWithinAABB(EntityFish.class, player.getEntityBoundingBox().expand(64, 64, 64));
			for (EntityFish fish : list) {
				fishList.add(fish);
			}
			if (fishList.size() < maxProPlayer) {
				Random rand = new Random();
				BlockPos spawnPos = FishUtils.getRandomPos(world, pos, spawnRange);
				String entityName;
				int min;
				int max;
				if(rand.nextInt(70) == 0) {
					if(rand.nextInt(3) == 0) {
						entityName = "pufferfish";
						min = 1;
						max = 1;
					} else {
						entityName = "clownfish";
						min = 1;
						max = 2;
					}
				} else {
					if (rand.nextInt(3) == 0) {
						entityName = "salmon";
						min = 1;
						max = 4;
					} else {
						entityName = "cod";
						min = 1;
						max = 4;
					}
				}
				
				int amount;
				if (max <= 1) {
					amount = 1;
				} else {
					amount = rand.nextInt(max - min) + min;
				}
				
				for (int i = 0; i < amount; i++) {
					FishUtils.spawnFishByName(entityName, false, world, spawnPos);
				}
			}
			
		}
	}
	
	public void addSpawn(String entityName, int probability) {
		for (int i = 0; i < probability; i++) {
			spawnList.add(entityName);
		}
	}
	
	public static BlockPos getRandomPos(World world, BlockPos pos, int spawnRange) {
		
		if (pos.getY() >= 40 && pos.getY() <= 140) {
			
			Random rand = new Random();
			
			//x
			int minX = pos.getX() - spawnRange;
			int maxX = pos.getX() + spawnRange;
			int minMaxX = maxX - minX;
			if (minMaxX < 0) {
				minMaxX *= -1;
			}
			int randX = rand.nextInt(minMaxX);
			int x = minX + randX;
			
			//z
			int minZ = pos.getZ() - spawnRange;
			int maxZ = pos.getZ() + spawnRange;
			int minMaxZ = maxZ - minZ;
			if (minMaxZ < 0) {
				minMaxZ *= -1;
			}
			int randZ = rand.nextInt(minMaxZ);
			int z = minZ + randZ;
			
			//y
			int minY = pos.getY() - 14;
			int maxY = pos.getY() + 4;
			int minMaxY = maxY - minY;
			if (minMaxY < 0) {
				minMaxY *= -1;
			}
			int randY = rand.nextInt(minMaxY);
			int y = minY + randY;
			
			BlockPos spawnPos = new BlockPos(x, y, z);
			
			int safeDistance = 16;
			if (world.getClosestPlayer(x, y, z, safeDistance, false) == null && MiscUtils.isWater(world, spawnPos)) {
				return spawnPos;
			}
			
		}
		
		return null;
	}
}
