package livingfish.handlers;

import livingfish.utils.FishUtils;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.WorldTickEvent;

public class WorldEvent {

	@SubscribeEvent
	public void worldTick(WorldTickEvent event) {
		if (event.side.isServer()) {
			World world = event.world;
			FishUtils.trySpawn(world);
		}
	}
	
}
