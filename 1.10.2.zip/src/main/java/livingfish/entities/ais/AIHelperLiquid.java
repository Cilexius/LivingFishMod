package livingfish.entities.ais;

import net.minecraft.entity.Entity;

public class AIHelperLiquid {

	public static boolean isInLiquid(Entity entity) {
		return entity.isInWater();
	}
}
