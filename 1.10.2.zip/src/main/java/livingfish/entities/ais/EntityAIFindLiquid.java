package livingfish.entities.ais;

import java.util.Random;

import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.FMLLog;

public class EntityAIFindLiquid extends EntityAIBase {
	
	private EntityCreature theCreature;
	private double liquidX;
	private double liquidY;
	private double liquidZ;
	private double movementSpeed;
	private World theWorld;

	public EntityAIFindLiquid(EntityCreature creature, double speed) {
		  this.theCreature = creature;
		  this.movementSpeed = speed;
		  this.theWorld = creature.worldObj;
		  setMutexBits(1);
	}

	public boolean shouldExecute() {
		if (AIHelperLiquid.isInLiquid(this.theCreature)) {
			  return false;
		}
		Vec3d vec3 = findLiquid();
		if(vec3 == null) {
			return false;
		}
		this.liquidX = vec3.xCoord;
		this.liquidY = vec3.yCoord;
		this.liquidZ = vec3.zCoord;
		  
		return true;
	}

	public boolean continueExecuting() {
		System.out.println("continuere aqua");
		return (!AIHelperLiquid.isInLiquid(this.theCreature));
	}

	public void startExecuting() {
		FMLLog.info("Navigating to liquid: " + this.liquidX + ", " + this.liquidY + ", " + this.liquidZ, new Object[0]);
		  //((PathNavigateFish)this.theCreature.getNavigator()).tryMoveToXYZDirectly(this.liquidX, this.liquidY, this.liquidZ, this.movementSpeed);
	}

	private Vec3d findLiquid() {
		Random random = this.theCreature.getRNG();
        BlockPos blockpos = new BlockPos(this.theCreature.posX, this.theCreature.getEntityBoundingBox().minY, this.theCreature.posZ);
		for(int i = 0; i < 10; i++) {
            BlockPos blockpos1 = blockpos.add(random.nextInt(10) - 5.0D,  random.nextInt(6) - 3.0D, random.nextInt(10) - 5.0D);
			Material material = this.theWorld.getBlockState(blockpos1).getMaterial();
			if (material == Material.WATER) {
				return new Vec3d((double)blockpos1.getX(), (double)blockpos1.getY(), (double)blockpos1.getZ());
			}
		}
		return null;
	}
}
