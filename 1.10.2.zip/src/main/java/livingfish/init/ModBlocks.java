package livingfish.init;

import livingfish.blocks.BlockTank;
import livingfish.utils.RegistryUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.properties.IProperty;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.statemap.StateMap;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModBlocks {

	public static Block tank;
	
	public void init() {
		tank = new BlockTank();
		RegistryUtils.setNames(tank, "tank");
	}

	public void register() {
		registerBlock(tank);
	}

	public void registerBlock(Block block) {
		GameRegistry.register(block);
		ItemBlock itemblock = new ItemBlock(block);
		itemblock.setUnlocalizedName(block.getUnlocalizedName()).setRegistryName(block.getRegistryName());
		GameRegistry.register(itemblock);
	}
	
	public static void registerModel() {
		ModelLoader.setCustomStateMapper(tank, new StateMap.Builder().ignore(new IProperty[] { BlockLiquid.LEVEL }).build());
		RegistryUtils.registerModel(tank, 0, new ModelResourceLocation(tank.getRegistryName(), "inventory"));
	}
	
}
