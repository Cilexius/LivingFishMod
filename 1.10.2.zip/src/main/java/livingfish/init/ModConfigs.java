package livingfish.init;

import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ModConfigs {

	public void register(FMLPreInitializationEvent event) {
    	Configuration config = new Configuration(event.getSuggestedConfigurationFile());
    	
    	config.load();
    	this.spawns(config);
    	config.save();
	}
	
	public static void spawns(Configuration config) {
		
	}

}
