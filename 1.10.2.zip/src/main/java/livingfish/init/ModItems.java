package livingfish.init;

import livingfish.items.Fishingrod;
import livingfish.items.ItemFishBucket;
import livingfish.utils.RegistryUtils;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModItems {
		
	public static Item fish_bucket_cod;
	public static Item fish_bucket_salmon;
	public static Item fish_bucket_clownfish;
	public static Item fish_bucket_pufferfish;
	
	public static Item ironhook;
	
	public static Item fishingrod;
	
	public void init() {
		fish_bucket_cod = new ItemFishBucket("cod");
		RegistryUtils.setNames(fish_bucket_cod, "fish_bucket_cod");
		fish_bucket_cod = new ItemFishBucket("cod");
		RegistryUtils.setNames(fish_bucket_cod, "fish_bucket_cod");
		fish_bucket_salmon = new ItemFishBucket("salmon");
		RegistryUtils.setNames(fish_bucket_salmon, "fish_bucket_salmon");
		fish_bucket_clownfish = new ItemFishBucket("clownfish");
		RegistryUtils.setNames(fish_bucket_clownfish, "fish_bucket_clownfish");
		fish_bucket_pufferfish = new ItemFishBucket("pufferfish");
		RegistryUtils.setNames(fish_bucket_pufferfish, "fish_bucket_pufferfish");
		
		ironhook = new Item().setCreativeTab(CreativeTabs.MISC);
		RegistryUtils.setNames(ironhook, "ironhook");
		
		fishingrod = new Fishingrod().setCreativeTab(CreativeTabs.TOOLS);
		RegistryUtils.setNames(fishingrod, "fishingrod");
	}
	
	public void register() {
		registerItem(fish_bucket_cod);
		registerItem(fish_bucket_salmon);
		registerItem(fish_bucket_clownfish);
		registerItem(fish_bucket_pufferfish);
		
		registerItem(ironhook);
		
		registerItem(fishingrod);
	}
	
	private void registerItem(Item item) {
		GameRegistry.register(item);
	}
	
	public static void registerModel() {
		RegistryUtils.registerModel(fish_bucket_cod, 0, new ModelResourceLocation(fish_bucket_cod.getRegistryName(), "inventory"));
		RegistryUtils.registerModel(fish_bucket_salmon, 0, new ModelResourceLocation(fish_bucket_salmon.getRegistryName(), "inventory"));
		RegistryUtils.registerModel(fish_bucket_clownfish, 0, new ModelResourceLocation(fish_bucket_clownfish.getRegistryName(), "inventory"));
		RegistryUtils.registerModel(fish_bucket_pufferfish, 0, new ModelResourceLocation(fish_bucket_pufferfish.getRegistryName(), "inventory"));
		
		RegistryUtils.registerModel(ironhook, 0, new ModelResourceLocation(ironhook.getRegistryName(), "inventory"));
		
		RegistryUtils.registerModel(fishingrod, 0, new ModelResourceLocation(fishingrod.getRegistryName(), "inventory"));
	}
	
}
